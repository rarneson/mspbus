This data feed no longer includes data for the Minnesota Valley Transit Authority (MVTA). MVTA data can downloaded here. http://www.datafinder.org/metadata/mvtaschedule.htm.

6/1/2011
The stop_url field in stops.txt is now populated with the URL to open the stop in NexTrip.